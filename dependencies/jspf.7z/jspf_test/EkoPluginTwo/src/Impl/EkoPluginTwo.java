package Impl;

import pluginInterface.SomePlugin;

/**
 * Created by eko on 10.12.2014.
 */
public class EkoPluginTwo implements SomePlugin {

    public String whoAmI() {
        return "I am EkoPlugin number two";
    }
}
