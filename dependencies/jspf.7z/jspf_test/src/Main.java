import net.xeoh.plugins.base.PluginManager;
import net.xeoh.plugins.base.impl.PluginManagerFactory;
import pluginInterface.SomePlugin;
import tmp.pluginInterface.ekoPlugin;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;


public class Main {

    public static void main(String[] args) throws URISyntaxException {
        PluginManager pm = PluginManagerFactory.createPluginManager();


        pm.addPluginsFrom(new URI("classpath://*"));

        ekoPlugin plugin = pm.getPlugin(ekoPlugin.class);
        System.out.println(plugin.saySomething());



        File f = new File("c:/temp/plugins/EkoPluginOne.jar");
        boolean exists = f.exists();
        URI uri = f.toURI();

        pm.addPluginsFrom(uri);
        SomePlugin somePlugin = pm.getPlugin(SomePlugin.class);
        System.out.println(somePlugin.whoAmI());


        }
}
