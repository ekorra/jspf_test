package pluginInterface;

import net.xeoh.plugins.base.Plugin;

/**
 * Created by eko on 10.12.2014.
 */
public interface SomePlugin extends Plugin {
    public String whoAmI();
    //
}
